package atividade4;

import java.io.*;
import java.util.Scanner;

public class Principal {
	private static ColecaoPessoa pessoa = new ColecaoPessoa(); 
	
	public static void main(String[] args) throws Exception{
		int op = 0;
		String str = null;
		Scanner sc = new Scanner(System.in);
		
		do{
			
			System.out.println("\n\nMenu ");
			System.out.println("0- Sair");
			
			System.out.println("\nPessoa:");
			System.out.println("1- Adicionar Pessoa");
			System.out.println("2- Salvar as pessoas em arquivo");
			System.out.println("3- Recuparar arquivo salvo");
			System.out.println("4- Listar pessoa");
			System.out.println("5- Remover Pessoa");
			System.out.print("Opc��o: ");
			op = sc.nextInt();

			switch(op){
				case 1:
					addPessoa();
					break;
				case 2:
					pessoa.salvarArquivo();
					break;
				case 3:
					recuperarArquivo();
					break;
				case 4:
					pessoa.listarPessoa();
					break;
				case 5:
					System.out.print("digite o CPF: ");
					str = lerDocumento();
					pessoa.removerPessoa(str);
					break;
				case 0:
					break;
			}
			sc.hasNextLine();
		}while(op != 0);
			
		
	}
	
	public static String lerDocumento(){
		Scanner sc = new Scanner(System.in);
		
		if( !sc.hasNextInt())
		{
			sc.next();
			System.out.printf("\nvoce deve digitar um numero: ");
			return lerDocumento();
		}
		return sc.nextLine();
	}
	
	public static boolean addPessoa() throws Exception{
		Scanner sc = new Scanner(System.in);
		String str = new String();
		Pessoa p = new Pessoa();
		
		System.out.print("digite o nome da pessoa: ");
		str = sc.nextLine();
		p.setNome(str);
		System.out.print("digite o CPF da pessoa: ");
		str = sc.nextLine();
		p.setCPF(str);
		
		if(pessoa.addPessoa(p)){
			return true;
		}else{
			return false;
		}
		
	}
	
	public static boolean recuperarArquivo() throws Exception{
		Scanner sc = new Scanner(System.in);
		String str = new String();
		
		System.out.print("digite o nome do arquivo em seu local: ");
		str = sc.nextLine(); 
		pessoa.recuperarArquivo(str);
		return true;
	}

}
