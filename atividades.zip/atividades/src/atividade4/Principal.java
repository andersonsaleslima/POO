package atividade4;

import java.io.*;
import java.util.Scanner;

public class Principal {
	private static ColecaoPessoa pessoa = new ColecaoPessoa(); 
	
	public static void main(String[] args) throws Exception{
		int op = 0;
		Scanner sc = new Scanner(System.in);
		
		do{
			System.out.println("Menu ");
			System.out.println("0- Sair");
			
			System.out.println("\nPessoa:");
			System.out.println("1- Adicionar Pessoa");
			System.out.println("2- Salvar as pessoas em arquivo");
			System.out.println("3- Recuparar arquivo salvo");
			op = sc.nextInt();

			switch(op){
				case 1:
					addPessoa();
				case 2:
					salvarArquivo();
				case 3:
					recuperarArquivo();
				case 0:
					break;
			}
		}while(op != 0);
			
		
	}
	
	public static boolean addPessoa() throws Exception{
		Scanner sc = new Scanner(System.in);
		String str = new String();
		Pessoa p = new Pessoa();
		
		System.out.print("digite o nome da pessoa: ");
		str = sc.nextLine();
		p.setNome(str);
		System.out.print("digite o CPF da pessoa: ");
		str = sc.nextLine();
		p.setCPF(str);
		
		if(pessoa.addPessoa(p)){
			return true;
		}else{
			return false;
		}
		
	}
	
	public static boolean salvarArquivo() throws Exception{
		Scanner sc = new Scanner(System.in);
		String str = new String();
		
		System.out.print("digite o local do arquivo: ");
		str = sc.nextLine();
		FileOutputStream saveFile = new FileOutputStream(str); 
		pessoa.SalvarArquivo(saveFile);
		return true;
	}
	
	public static boolean recuperarArquivo() throws Exception{
		Scanner sc = new Scanner(System.in);
		String str = new String();
		
		System.out.print("digite o local do arquivo: ");
		str = sc.nextLine();
		FileInputStream File = new FileInputStream(str); 
		pessoa.recuperarArquivo(File);
		return true;
	}

}
