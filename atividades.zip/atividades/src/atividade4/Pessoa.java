package atividade4;

public class Pessoa {
	String Nome;
	String CPF;
	
	/**
	 * 
	 */
	public Pessoa() {
		super();
	}
	
	/**
	 * @param nome
	 * @param cPF
	 */
	public Pessoa(String nome, String cPF) {
		super();
		Nome = nome;
		CPF = cPF;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return Nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		Nome = nome;
	}

	/**
	 * @return the cPF
	 */
	public String getCPF() {
		return CPF;
	}

	/**
	 * @param cPF the cPF to set
	 */
	public void setCPF(String cPF) {
		CPF = cPF;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((CPF == null) ? 0 : CPF.hashCode());
		result = prime * result + ((Nome == null) ? 0 : Nome.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Pessoa)) {
			return false;
		}
		Pessoa other = (Pessoa) obj;
		if (CPF == null) {
			if (other.CPF != null) {
				return false;
			}
		} else if (!CPF.equals(other.CPF)) {
			return false;
		}
		if (Nome == null) {
			if (other.Nome != null) {
				return false;
			}
		} else if (!Nome.equals(other.Nome)) {
			return false;
		}
		return true;
	}
	
	
}
