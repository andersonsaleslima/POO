package atividade4;

import java.util.Collections;
import java.util.ArrayList;
import java.io.*;

public class ColecaoPessoa implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<Pessoa> pessoa = new ArrayList();

	
	/**
	 * 
	 */
	public ColecaoPessoa() {
		super();
	}

	/**
	 * @param pessoa
	 */
	public ColecaoPessoa(ArrayList<Pessoa> pessoa) {
		super();
		this.pessoa = pessoa;
	}
	
	public boolean  addPessoa(Pessoa pessoa)throws Exception{
		try{
			this.pessoa.add(pessoa);
			return true;
		}catch(Exception e){
			System.err.println("erro ao adionar");
			return false;
		}
	}
	
	public void salvarArquivo() throws IOException{
		try{
			FileOutputStream saveFile = new FileOutputStream("pessoa.txt"); 
			ObjectOutputStream stream = new ObjectOutputStream(saveFile);
			stream.writeObject(this.pessoa);
			System.out.println(stream.toString());
			stream.close();
		}catch(IOException io){
			System.err.println("erro ao salvar arquivo");
		}
	}
	
	public void recuperarArquivo(String str) throws IOException, ClassNotFoundException{
		try{
			FileInputStream file = new FileInputStream(str); 
			ObjectInputStream stream = new ObjectInputStream(file);
			this.pessoa = (ArrayList<Pessoa>) stream.readObject();
			stream.close();
		}catch(IOException io){
			System.err.println("erro ao obter arquivo");
		}
	}
	
	public void listarPessoa()throws Exception{
		try{
			for (Pessoa p : this.pessoa) {
				System.out.println(p.toString());
			}
			
		}catch(Exception e){
			System.err.println("erro ao listar\n");
		}
		
	}
	
	public boolean removerPessoa(String cpf)throws Exception{
		try{
			for (Pessoa p : this.pessoa) {
				if(p.getCPF().equals(cpf)){
					this.pessoa.remove(p);
					return true;
				}
			}
			return false;
		}catch(Exception e){
			System.err.println("erro ao remover\n");
			return false;
		}
	}
	
}
