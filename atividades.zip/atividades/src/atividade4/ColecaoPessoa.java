package atividade4;

import java.util.Collections;
import java.util.ArrayList;
import java.io.*;

public class ColecaoPessoa {
	private ArrayList<Pessoa> pessoa = new ArrayList();

	
	/**
	 * 
	 */
	public ColecaoPessoa() {
		super();
	}

	/**
	 * @param pessoa
	 */
	public ColecaoPessoa(ArrayList<Pessoa> pessoa) {
		super();
		this.pessoa = pessoa;
	}
	
	public boolean  addPessoa(Pessoa pessoa)throws Exception{
		try{
			this.pessoa.add(pessoa);
			return true;
		}catch(Exception e){
			System.err.println("erro ao adionar");
			return false;
		}
	}
	
	public void SalvarArquivo(FileOutputStream saveFile) throws IOException{
		try{
			ObjectOutputStream stream = new ObjectOutputStream(saveFile);
			stream.writeObject(this.pessoa);
			stream.close();
		}catch(IOException io){
			System.err.println("erro ao salvar arquivo");
		}
	}
	
	public void recuperarArquivo(FileInputStream file) throws IOException, ClassNotFoundException{
		try{
			ObjectInputStream stream = new ObjectInputStream(file);
			this.pessoa = (ArrayList<Pessoa>) stream.readObject();
			stream.close();
		}catch(IOException io){
			System.err.println("erro ao obter arquivo");
		}
	}
	
	
}
